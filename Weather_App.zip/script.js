
async function getWeather() {
    const location = document.getElementById("locationInput").value;
    const apiKey = "YOUR_API_KEY"; // Replace with your OpenWeatherMap API key
    const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${apiKey}&units=metric`);
    const data = await response.json();

    if (data.cod === 200) {
        document.getElementById("weatherResult").innerHTML = `
            <p><strong>Location:</strong> ${data.name}</p>
            <p><strong>Temperature:</strong> ${data.main.temp} °C</p>
            <p><strong>Condition:</strong> ${data.weather[0].description}</p>
        `;
    } else {
        document.getElementById("weatherResult").innerHTML = "<p>Location not found. Try again.</p>";
    }
}
